package com.jcg.jdbc.connection.pooling;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Properties;
import javax.sql.DataSource;
import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbcp.PoolingDataSource;
import org.apache.commons.pool.impl.GenericObjectPool;

/**
 * @author - Laknath Ranasinghe
 * @Date - 08-21-2018
 * 
 */

public class PostgresDbManager {
	
	Properties prop = new Properties();
	  InputStream input = getClass().getClassLoader().getResourceAsStream("resources/config.properties");
	  //InputStream input = VBrainDbManager.class.getClassLoader().getResourceAsStream("config.properties");

	private static GenericObjectPool gPool = null;
	static final String POSTGRES_DRIVER = "org.postgresql.Driver";

	@SuppressWarnings("unused")
	public DataSource setUpPool() throws Exception {
		Class.forName(POSTGRES_DRIVER);

		// Creates an Instance of GenericObjectPool That Holds Our Pool of Connections
		// Object!
		gPool = new GenericObjectPool();
		gPool.setMaxActive(5);
		if (input != null) {
			prop.load(input);
		} else {
			throw new FileNotFoundException("property file not found in the classpath");
		}
		// Creates a ConnectionFactory Object Which Will Be Use by the Pool to Create
		// the Connection Object!
		ConnectionFactory cfwf = new DriverManagerConnectionFactory(prop.getProperty("JDBC_DB_URL_03"), prop.getProperty("JDBC_POSTGRES_USER"), prop.getProperty("JDBC_POSTGRES_PASS"));
		// Creates a PoolableConnectionFactory That Will Wraps the Connection Object
		// Created by the ConnectionFactory to Add Object Pooling Functionality!
		PoolableConnectionFactory pcfwf = new PoolableConnectionFactory(cfwf, gPool, null, null, false, true);

		return new PoolingDataSource(gPool);
	}

	public GenericObjectPool getConnectionPool() {
		return gPool;
	}

	// This Method Is Used To Print The Connection Pool Status
	private void printDbStatus() {
		System.out.println("Max.: " + getConnectionPool().getMaxActive() + "; Active: "
				+ getConnectionPool().getNumActive() + "; Idle: " + getConnectionPool().getNumIdle());
	}


}
