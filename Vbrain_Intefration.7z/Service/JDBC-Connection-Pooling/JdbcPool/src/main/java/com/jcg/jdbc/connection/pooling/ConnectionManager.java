package com.jcg.jdbc.connection.pooling;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.sql.DataSource;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * @author - Laknath Ranasinghe
 * @Date - 08-21-2018
 * 
 */

public class ConnectionManager {

	static String newupdateddate = "";

	public static void main(String[] args) {

		ResultSet rsObj = null;
		ResultSet rsObjForIncident = null;
		ResultSet rsObjforbot = null;
		Connection connObjVb = null;
		Connection connObjWf = null;
		Connection connObjPostgres = null;
		PreparedStatement pstmtObjForCampaignData = null;
		PreparedStatement pstmtObjFordatetime = null;
		PreparedStatement pstmtObjForbotid = null;
		PreparedStatement pstmtObjForinsert = null;
		PreparedStatement pstmtObjdeleterecords = null;
		PreparedStatement pstmtObjForSelect = null;

		DateTime lastrecordtime = null;

		WfDbManager wfmgr = new WfDbManager();
		VBrainDbManager vbrainmgr = new VBrainDbManager();
		PostgresDbManager postgressmgr = new PostgresDbManager();

		try {

			DataSource dataSourceVB = vbrainmgr.setUpPool();
			DataSource dataSourceWF = wfmgr.setUpPool();
			DataSource dataSourcePostgres = postgressmgr.setUpPool();

			// Performing Database Operation!
			System.out.println("\n=====Making A New Connection Object For Db Transaction=====\n");
			connObjVb = dataSourceVB.getConnection();
			connObjWf = dataSourceWF.getConnection();
			connObjPostgres = dataSourcePostgres.getConnection();

			// Delete values from the temparary table
			pstmtObjdeleterecords = deleteTempTransactions(connObjVb);
			pstmtObjdeleterecords.executeUpdate();

			// create insert Statement to insert data in to vBrain-Transaction table
			PreparedStatement insertObj = createTransactions(connObjVb);
			PreparedStatement insertincidentObj = createIncidents(connObjVb);

			// select last execution time from the vBrain- wf- config table
			pstmtObjFordatetime = selectLastRecordDatetime(connObjVb);
			rsObj = pstmtObjFordatetime.executeQuery();

			if (rsObj.next()) {
				lastrecordtime = convertToStandardTime(rsObj.getObject("LASTRECORD_TIMESTAMP").toString());
			} else if (lastrecordtime == null) {
				lastrecordtime = DateTime.now();
			}

			// Select Bp Related data from vbrain tables
			pstmtObjForCampaignData = selectCampaignData(connObjWf, lastrecordtime);
			rsObj = pstmtObjForCampaignData.executeQuery();
			pstmtObjForinsert = insertTempTransactions(connObjVb);

			while (rsObj.next()) {
				pstmtObjForinsert = convertCompaignData(pstmtObjForinsert, rsObj);
				pstmtObjForinsert.addBatch();
			}

			pstmtObjForinsert.executeBatch();
			int records = 0;

			pstmtObjForbotid = getBotDetails(connObjVb);
			rsObjforbot = pstmtObjForbotid.executeQuery();
			String bpUUID = "";
			

			while (rsObjforbot.next()) {
				System.out.println(rsObjforbot.getString("bp_instance_uuid"));
				int numberOfRows = rsObjforbot.getInt(5);
				if (numberOfRows > 0) {
					insertObj = convertToObj(insertObj, rsObjforbot, lastrecordtime);
					insertObj.addBatch();
					System.out.println(bpUUID);
					System.out.println(rsObjforbot.getString("status"));
					
					if (rsObjforbot.getString("status").equals("1") && !(bpUUID.equals(rsObjforbot.getString("bp_instance_uuid")))) {
						//Insert Object will be completed in postgress database
						insertincidentObj = convertToObjForInsert(connObjPostgres, insertincidentObj, rsObjforbot);
						insertincidentObj.addBatch();
					}
					bpUUID=rsObjforbot.getString("bp_instance_uuid");
					System.out.println(bpUUID);
					records += 1;
				}
			}
			
			System.out.println(records + " records added..");

			insertObj.executeBatch();
			insertincidentObj.executeBatch();
			// Update lastest recodrd time field in configuration table

			String newdate = getNewupdateddate();

			if ((newdate != null) && !(newdate.equals(""))) {

				String updatesql = "UPDATE vbrain.wf_configuration\r\n" + "SET LASTRECORD_TIMESTAMP = \'" + newdate
						+ "'";
				PreparedStatement updateobj = connObjVb.prepareStatement(updatesql);
				updateobj.executeUpdate();
			}

			System.out.println("\n=====Releasing Connection Object To Pool=====\n");

		} catch (

		Exception sqlException) {
			sqlException.printStackTrace();
		} finally {
			try {
				// Closing ResultSet Object
				if (rsObj != null) {
					rsObj.close();
				}
				if (rsObjforbot != null) {
					rsObjforbot.close();
				}
				// Closing PreparedStatement Object
				if (pstmtObjForCampaignData != null) {
					pstmtObjForCampaignData.close();
				}
				if (pstmtObjFordatetime != null) {
					pstmtObjFordatetime.close();
				}
				if (pstmtObjForbotid != null) {
					pstmtObjForbotid.close();
				}
				// Closing Connection Object
				if (connObjWf != null) {
					connObjWf.close();
				}
				if (connObjVb != null) {
					connObjVb.close();
				}
			} catch (Exception sqlException) {
				sqlException.printStackTrace();
			}
		}
	}

	private static String getNewupdateddate() {
		return newupdateddate;
	}

	public static void setNewupdateddate(String newdate) {
		newupdateddate = newdate;
	}

	static DateTime convertToStandardTime(String datetime) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		Date coverteddatewithseconds = formatter.parse(datetime);
		String converttosimpledateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(coverteddatewithseconds);
		DateTimeFormatter formatters = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
		DateTime converteddatetimeobj = formatters.parseDateTime(converttosimpledateformat);
		return converteddatetimeobj;
	}

	static String convertToStandartFormat(String datetime) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		Date coverteddatewithseconds = formatter.parse(datetime);
		String converttosimpledateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(coverteddatewithseconds);
		return converttosimpledateformat;
	}

	static PreparedStatement createTransactions(Connection con) throws SQLException {
		String inserttranasactiondata = "INSERT INTO vbrain.transactions(" + "WORKER_ID," + "WORKER_TYPE," + "STATUS,"
				+ "START_TIME," + "END_TIME," + "OUT_COME," + "EXCEPTION_TYPE," + "DESCRIPTION," + "CREATED_BY,"
				+ "TRACKING_ID," + "COUNTRY," + "B_FUNCTION)" + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

		PreparedStatement insertObj = con.prepareStatement(inserttranasactiondata);
		return insertObj;
	}

	static PreparedStatement createIncidents(Connection con) throws SQLException {
		String insertincidentdata = "INSERT INTO vbrain_incidents (" + "TICKET_ID," + "STATUS," + "DESCRIPTION,"
				+ "CREATED_BY," + "TRANSACTION_ID,"+ "BOT_ID,"+ "TRACKING_ID)" + "VALUES(?,?,?,?,?,?,?)";

		PreparedStatement insertincidentObj = con.prepareStatement(insertincidentdata);
		return insertincidentObj;
	}

	static PreparedStatement deleteTempTransactions(Connection con) throws SQLException {
		String deletedata = "DELETE FROM vbrain.wf_temp_transactions";

		PreparedStatement deleteObj = con.prepareStatement(deletedata);
		return deleteObj;
	}

	static PreparedStatement insertTempTransactions(Connection con) throws SQLException {
		String inserttemptranasactiondata = "INSERT INTO vbrain.wf_temp_transactions(" + "STATUS," + "TITLE,"
				+ "BP_NAME," + "START_TIME," + "END_TIME," + "DESCRIPTION ,"+ "BP_UUID)" + "VALUES(?,?,?,?,?,?,?)";

		PreparedStatement inserttempObj = con.prepareStatement(inserttemptranasactiondata);
		return inserttempObj;
	}

	static PreparedStatement selectLastRecordDatetime(Connection con) throws SQLException {
		String selecttimestamp = "SELECT LASTRECORD_TIMESTAMP FROM vbrain.wf_configuration";

		PreparedStatement insertObj = con.prepareStatement(selecttimestamp);
		return insertObj;
	}

	static PreparedStatement selectCampaignData(Connection con, DateTime lastrecordtime) throws SQLException {
		String selectcampagindaata = "select r.title as stepTitle\r\n" + ", bp.title as bpname\r\n"
				+ ", ah.submissionDate as hit_submissionDate\r\n" + ", r.startDate as step_startDate\r\n"
				+ ", r.rootRunUUID as bp_instance_uuid\r\n" + ", ah.completionDate as hit_completionDate\r\n"
				+ ",r.hasProcessingIssues as status \r\n" + "from wfdb.Run r \r\n"
				+ "join Campaign bp on bp.id = r.campaign_id\r\n"
				+ "join CampaignMap cm on r.campaignMap_id = cm.id\r\n" + "join Campaign c on c.id = cm.campaign\r\n"
				+ "left join MACHINE_CONFIG mc on mc.id = c.machineConfigId\r\n"
				+ "join AwsHit ah on ah.run_id = r.id\r\n" + "left join AwsHitAssignment aha on aha.hit_id = ah.id\r\n"
				+ "left join MachineCampaignSource mcs on mcs.id = mc.source_id\r\n" + "where  ah.submissionDate >'"
				+ lastrecordtime + "'\r\n" + "AND mc.content like '%selenium%' \r\n"
				+ "AND r.executingType = 'MACHINE' \r\n" + "AND (r.status='COMPLETED' OR r.hasProcessingIssues = 1)\r\n"
				+ "Order by ah.submissionDate;\r\n";

		PreparedStatement insertObj = con.prepareStatement(selectcampagindaata);
		return insertObj;
	}

	static PreparedStatement getBotDetails(Connection con) throws SQLException {
		String selectrundata = "select country.Name as country, \r\n" + "lob.Name as lob, \r\n"
				+ "func.Name as function, \r\n" + "bp.Name as bpname, \r\n" + "b.ID as botid, \r\n"
				+ "b.Bot_Key as botkey,\r\n" + "temp.STATUS as status,\r\n"
				+ "temp.START_TIME as hit_submissionDate,\r\n" + "temp.END_TIME as hit_completionDate,\r\n"
				+ "temp.DESCRIPTION as stepTitle, \r\n"+ "temp.BP_UUID as bp_instance_uuid \r\n" + "from groups bp\r\n" + "join bot b on bp.ID = b.Process_Id\r\n"
				+ "join groups func on bp.Parent_Id = func.ID\r\n" + "join groups lob on func.Parent_Id = lob.ID\r\n"
				+ "join groups country on lob.Parent_Id = country.ID\r\n"
				+ "inner join wf_temp_transactions temp on temp.BP_NAME = bp.Name";

		PreparedStatement insertObj = con.prepareStatement(selectrundata);
		return insertObj;
	}

	static PreparedStatement convertToObj(PreparedStatement insertObj, ResultSet rsObjforbot, DateTime lastrecordtime)
			throws ParseException, SQLException {

		DateTime convertedstartedtime = convertToStandardTime(rsObjforbot.getString("hit_submissionDate"));

		if (lastrecordtime.isBefore(convertedstartedtime)) {
			lastrecordtime = convertedstartedtime;
			String newupdateddate = convertToStandartFormat(rsObjforbot.getString("hit_submissionDate"));
			setNewupdateddate(newupdateddate);
		}

		insertObj.setString(1, rsObjforbot.getString("botid"));
		insertObj.setString(2, "BOT");
		insertObj.setString(3, rsObjforbot.getString("status"));
		insertObj.setString(4, rsObjforbot.getString("hit_submissionDate"));
		insertObj.setString(5, rsObjforbot.getString("hit_completionDate"));
		insertObj.setString(6, "0");
		insertObj.setString(7, (rsObjforbot.getString("status").equals("1")) ? "Unkown Error" : "");
		insertObj.setString(8, rsObjforbot.getString("stepTitle"));
		insertObj.setString(9, "vBrain");
		insertObj.setString(10, "bp_instance_uuid");
		insertObj.setString(11, rsObjforbot.getString("country"));
		insertObj.setString(12, rsObjforbot.getString("function"));

		return insertObj;
	}

	static PreparedStatement convertToObjForInsert(Connection con, PreparedStatement insertObj, ResultSet rsObjforbot)
			throws ParseException, SQLException {

		// execute below query
		PreparedStatement pstmtObjForSelect = selectLastRecordWithDate(con, rsObjforbot);
		ResultSet rsObjForIncident = pstmtObjForSelect.executeQuery();
		if (rsObjForIncident.next()) {
			String ticketID = createServiceNowIncident();

			insertObj.setString(1, ticketID);
			insertObj.setString(2, "Open");
			insertObj.setString(3, rsObjForIncident.getString("error_msg"));
			insertObj.setString(4, "vBrain");
			insertObj.setString(5, "0");
			insertObj.setString(6, rsObjforbot.getString("botid"));
			insertObj.setString(7, rsObjforbot.getString("bp_instance_uuid"));
		}
		return insertObj;

	}

	static String createServiceNowIncident() throws ParseException {
		String ticketID = "INC000000";
		return ticketID;
	}

	static PreparedStatement selectLastRecordWithDate(Connection con, ResultSet rsObjforbot) throws SQLException {
		String psqlTblName = "ds_" + rsObjforbot.getString("bpname") + "_run_statistics";

		// execute below query
		String selecttblname = "Select * from `" + psqlTblName + "` Where start_date = '"
				+ rsObjforbot.getString("hit_submissionDate") + "'";

		PreparedStatement selecttbl = con.prepareStatement(selecttblname);
		return selecttbl;
	}

	static PreparedStatement convertCompaignData(PreparedStatement insertObjforCampaign, ResultSet rsObjforCampaign)
			throws SQLException {
		insertObjforCampaign.setString(1, rsObjforCampaign.getString("status"));
		insertObjforCampaign.setString(2, rsObjforCampaign.getString("stepTitle"));
		insertObjforCampaign.setString(3, rsObjforCampaign.getString("bpname"));
		insertObjforCampaign.setString(4, rsObjforCampaign.getString("hit_submissionDate"));
		insertObjforCampaign.setString(5, rsObjforCampaign.getString("hit_completionDate"));
		insertObjforCampaign.setString(6, rsObjforCampaign.getString("stepTitle"));
		insertObjforCampaign.setString(7, rsObjforCampaign.getString("bp_instance_uuid"));

		return insertObjforCampaign;
	}
}